from .pypse_run import pypse_run as run
from .shell import launch

name = "pypse"
