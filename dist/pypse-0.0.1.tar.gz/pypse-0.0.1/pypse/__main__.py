from pypse import shell

shell.launch()
