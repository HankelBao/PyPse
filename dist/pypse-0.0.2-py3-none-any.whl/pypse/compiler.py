VERSION = "0.0.x"
DEBUG = False
WARNING_MODE = True
